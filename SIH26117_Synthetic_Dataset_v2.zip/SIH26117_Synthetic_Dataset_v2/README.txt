SIH26117 SYNTHETIC INDUSTRIAL DATASET v2.0

ENTIRELY SYNTHETIC — NOT ACTUAL MRPL OPERATIONAL DATA.

WHAT WAS FIXED FROM v1:
1. P-101 now has numeric operating parameters and inspection records.
2. The current Operating Limits document no longer contains a dangling "supersedes Revision A" reference.
3. Ground truth now contains V-101 temperature and vibration limits, plus P-101 limits.
4. Added an existing-equipment/missing-parameter test: V-101 flow rate is intentionally absent.
5. Added a separate degraded OCR stress-test image/PDF for backup use only. The main OCR test remains clean and demo-safe.

PRIMARY DEMO:
V-101 inspection analysis:
14.5 bar observed vs 12 bar recommended upper limit = 20.83% deviation.
Absolute/design limit = 15 bar.
Temperature 94 C and vibration 5.2 mm/s RMS are within normal range.
Maintenance history includes prior pressure fluctuation and instrumentation drift/calibration.
Recommendation: verify measurement/instrument status and perform engineering review; human approval required.

SECOND EQUIPMENT DEMO:
P-101 discharge pressure = 5.4 bar; normal range 4–6 bar.
Use this to demonstrate generality and equipment-ID isolation.

NEGATIVE TESTS:
- Unknown equipment Z-999.
- Existing V-101 but missing flow-rate parameter.
- V-101 vs P-101 numeric distractor isolation.

IMPORTANT:
Do NOT ingest ground_truth/ground_truth.json into the agent's RAG corpus.
Use it only as an evaluation oracle.
The auxiliary degraded OCR asset is a stress test, not the primary live-demo path.
